from Bankaccount import BankAccount
def main():
    c= BankAccount("joaquin",207843334,741741456,"joaquindazalavin@gmail.com")

    print(c.get_password())
    c.deposit(5000)
    c.withdraw(2500)
    c.display()
    
if __name__ == "__main__":
    main()
