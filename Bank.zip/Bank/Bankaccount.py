class BankAccount:
    def __init__(self,name,personalid,password,email):
        
        self.__email = email
        self.__password = password
        self.__personalid= personalid
        self.__name = name
        self.__balance=0
        

    def get_balance(self):
        return self.__balance
    
    def get_name(self):
        return self.__name
    
    def get_personalid(self):
        return self.__personalid
    
    def get_password(self):
        return self.__password

    def get_email(self):
        return self.__email
    
    def set_email(self,email):
        self.__email = email

    def set_name(self,name):
        self.__name = name
    
    def set_personalid(self,personalid):
        self.__personalid = personalid
    
    def set_password(self,password):
        self.__password = password
    
    def display(self):
        print("Nombre: " + str(self.get_name()))
        print("Rut: " + str(self.get_personalid()))
        print("Balance: " + str(self.get_balance()))
        print("Correo/Email: " + self.get_email())    

    def deposit(self, deposit_amount):
        self.amount = deposit_amount
        if deposit_amount <= 0:
            print("Monto invalido")
        else:
            self.__balance += deposit_amount
            print("Deposito " + str(deposit_amount)+"$" + " en su cuenta")

    def withdraw(self, withdraw_amount):
        if withdraw_amount > self.__balance:
            print("Monto insuficiente")
        else :
            self.__balance -= withdraw_amount
            print("Retiro " + str(withdraw_amount)+"$" + " de su cuenta")
