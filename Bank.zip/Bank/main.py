from Bankaccount import BankAccount
def main():

    c = BankAccount("joaquin",207843334,123456,"joaquindazalavin@gmail.com")
    
    c.deposit(3000)
    c.withdraw(1500)
    print("El saldo de su cuenta es de: " + str(c.get_balance()) +"$")
if __name__ == "__main__":
    main()

