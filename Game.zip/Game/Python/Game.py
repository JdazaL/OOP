import random
import time
"""
time.sleep (0.3)
print("                              +---------------------------+     ")
time.sleep (0.3)
print("                              |\                          |\    ")
time.sleep (0.3)
print("                              | \                         | \ ")
time.sleep (0.3)
print("                              |  \                        |  \ ")
time.sleep (0.3)
print("______________________________|___|_______________________|___|__________________ ")
time.sleep (0.3)
print("         /                   /                           /                    / ")
time.sleep (0.3)
print("        /                   /  o                        /                    /")
time.sleep (0.3)
print("       /                   /  /|_        @             /                    /")
time.sleep (0.3)
print("      /                   /_ /\ ______________________/                    /")
time.sleep (0.3)
print("     /                      / /                                           /")
time.sleep (0.3)
print("    /                                                                    /")
time.sleep (0.3)
print("   /                                                                    /")
time.sleep (0.3)
print("  /____________________________________________________________________/")
"""




class Attribute():
    def __init__(self):
        self.level = 0
        self.attempts = 3
        self.goal_keeper_score = 0
        self.kicker_score = 0
class Goal_Keeper(Attribute):
    def __init__(self):
        super().__init__()
        self.option = 0

    def catch_direction(self,total):
        self.option = random.randint(1, 6)
        shot_angle = Player1.shoot_angle()
        if self.option <= total:
            
            print("El arquero atajo la pelota.")
            Player1.attempts -=1
            self.goal_keeper_score +=1
            
        else:
            print("GOLAZOOOOOOOOO!")
            print("Se ha aumentado la dificultad.")
            self.kicker_score +=1

class Kicker(Attribute):
    def __init__(self):
        super().__init__()
        self.option = 0

    def shoot_angle(self):
        while True:
            try:
                print("\n\nEscoja la direccion de la pelota\n\n")
                self.option = int(input("\n1) Arriba Derecha \n\n2) Abajo Derecha \n\n3) Arriba Centro \n\n4) Abajo centro \n\n5) Arriba Izquierda \n\n6) Abajo Izquierda \n\n"))
                if self.option in range(1, 7):
                    break
                else:
                    print("Opcion invalida, ingrese una de las opciones anteriores.")
            except ValueError:
                print("Por favor ingrese un numero entero.")
        return self.option
i=1
Player1 = Kicker()
Goal_Keeper0 = Goal_Keeper()


while i<=4: 
    
    Goal_Keeper0.catch_direction(i)
    if Goal_Keeper0.goal_keeper_score==1 :
        print("Perdiste")
        break
   
    else:
        
        if i==4:
        
            print("ganaste xd")
        i+=1