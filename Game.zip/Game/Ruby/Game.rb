require 'time'

sleep(0.3)
puts("                              +---------------------------+     ")
sleep(0.3)
puts("                              |\                          |\    ")
sleep(0.3)
puts("                              | \                         | \ ")
sleep(0.3)
puts("                              |  \                        |  \ ")
sleep(0.3)
puts("______________________________|___|_______________________|___|__________________ ")
sleep(0.3)
puts("         /                   /                           /                    / ")
sleep(0.3)
puts("        /                   /  o                        /                    /")
sleep(0.3)
puts("       /                   /  /|_        @             /                    /")
sleep(0.3)
puts("      /                   /_ /\ ______________________/                    /")
sleep(0.3)
puts("     /                      / /                                           /")
sleep(0.3)
puts("    /                                                                    /")
sleep(0.3)
puts("   /                                                                    /")
sleep(0.3)
puts("  /____________________________________________________________________/")

class Game
  def initialize
    @level = 0
    @attempts = 3
    @goal_keeper_score = 0
    @kicker_score = 0
  end
  attr_reader :goal_keeper_score
end

class GoalKeeper < Game
  def initialize
    
    @option = 0
    @level = 0
    @attempts = 3
    @goal_keeper_score = 0
    @kicker_score = 0
  end

  def catch_direction(total)
    @option = rand(1..6)
    shot_angle = Player1.shoot_angle
    if @option <= total
      puts("El arquero atajo la pelota.")
      puts("PERDISTEEE")
      @attempts -= 1
      @goal_keeper_score += 1
    else
      puts("GOLAZOOOOOOOOO!")
      puts("Se ha aumentado la dificultad.")
      @kicker_score += 1
    end
  end
end


class Kicker < Game
  def initialize
    super
    @option = 0
    @level = 0
    @attempts = 3
    @goal_keeper_score = 0
    @kicker_score = 0
  end

  def shoot_angle
    while true
      begin
        puts("\n\nEscoja la direccion de la pelota\n1) Arriba Derecha \n\n2) Abajo Derecha \n\n3) Arriba Centro \n\n4) Abajo centro \n\n5) Arriba Izquierda \n\n6) Abajo Izquierda \n\n")
        @option = gets.chomp.to_i
        if @option.between?(1, 6)
          break
        else
          puts("Opcion invalida, ingrese una de las opciones anteriores.")
        end
      rescue ValueError
        puts("Por favor ingrese un numero entero.")
      end
    end
    @option
  end
end

i = 1
Player1 = Kicker.new
GoalKeeper0 = GoalKeeper.new

while i <= 4
  GoalKeeper0.catch_direction(i)
  if GoalKeeper0.goal_keeper_score == 1
    break
  else
    if i == 4
      puts("ganaste xd")
    end
  end
  i += 1
end
